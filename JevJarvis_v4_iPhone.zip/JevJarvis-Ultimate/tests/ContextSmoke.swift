import Foundation
// Stub only the two app-specific symbols needed by JevContext.swift on Linux.
enum JevLanguage { case english, chinese }
enum JevStore { static let appGroupID = "group.jev.smoke.local" }
@main struct ContextSmoke {
 static func main() {
  let unique = "jev.smoke.\(UUID().uuidString)"
  guard let defs = UserDefaults(suiteName: unique) else { fatalError("Cannot create test store") }
  let store = JevContextStore(defaults: defs)
  store.clear()
  store.append(.them, text: "你今天忙吗？")
  store.append(.them, text: "你今天忙吗？")
  assert(store.turns().count == 1, "Deduplication failed")
  store.recordExchange(incoming: "你今天忙吗？", reply: "下午有点事，晚上空")
  assert(store.turns().count == 2)
  assert(store.turns()[1].text.contains("未确认发送"), "Reply should not be marked sent")
  let prompt = store.contextString(forAnswering: "那晚上呢", language: .chinese)
  assert(prompt.contains("今天忙"))
  assert(prompt.contains("未确认发送"))
  store.clear()
  assert(store.turns().isEmpty)
  defs.removePersistentDomain(forName: unique)
  print("CONTEXT_DEDUP_PENDING_REPLY_OK")
 }
}
