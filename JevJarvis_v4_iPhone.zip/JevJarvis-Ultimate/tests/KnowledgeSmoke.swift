import Foundation
@main struct Smoke {
 static func main() {
  assert(GoutouKnowledgeEmbedded.files.count == 43)
  let cases: [(String, String)] = [
   ("吵架", "沟通冲突与修复"),
   ("冷淡不回", "关系投入失衡"),
   ("约会见面", "吸引约会与关系启动"),
   ("我好累", "为他人提供情绪价值")
  ]
  for (msg, expected) in cases {
   let answer = GoutouKnowledge.snippet(for: msg, context: nil)
   assert(answer.contains(expected), "Missing KB fallback \(expected): \(answer.prefix(100))")
  }
  print("KNOWLEDGE_FALLBACK_OK 43/43")
 }
}
