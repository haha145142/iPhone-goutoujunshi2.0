# JevJarvis 终极融合版（Ultimate）

> 本仓库在 Jev Jarvis（liuhai 版）基础上融合「666 / 狗头军师」的智能回复、上下文记忆与真人化表达，
> 并加固了键盘扩展防闪退。由 GitHub Actions 云编译未签名 IPA，全能签/爱思自签安装。

## 融合了什么

| 能力 | 来源 | 本版实现 |
|---|---|---|
| 键盘界面 / 打字体验 / 剪贴板自动分段 | Jev Jarvis liuhai 版（v2.0） | **完整保留**：分析剪贴板、AI 分析输入框、键盘内配置、一键导入配置 |
| 狗头军师 Skill（情绪/意图/关系阶段 + 3~5 条成品回复） | 666 / goutou-keyboard-ios | 技能文件打进键盘扩展 **+ 编译期内嵌兜底**，保证 Skill 一定进入 AI 请求 |
| 真人化回复（拒绝客服腔/机械套话） | 666 | 内置 realismRules + 本轮新增「有分寸的幽默」约束 |
| 最近 8~16 条上下文记忆（区分对方/我、自动携带、去重） | 666 / Jev Context | 分析剪贴板自动记「对方」、点候选自动记「我」；下次分析自动上传并标为历史 |
| 方法库按需命中（20 篇核心，命中 1~2 篇注入） | 狗头军师开源库 | 键盘侧单请求路径**真正接线**（原版只在 App 测试页接线） |
| 防闪退加固 | 本版新增 | 剪贴板读取自动释放池+限长；单请求架构；流程断点记录（中断后提示「上次被系统中断于：N」） |
| 知识库浏览（23 实战 + 7 童锦程，仅主 App） | v2.0 | 随 App 打包，不在键盘加载，保键盘稳定 |

## 关键修复

1. **「分析剪贴板」闪退跳回系统键盘**：保持 v2.0 的轻量单请求架构（不经多请求管线），
   剪贴板读取走自动释放池 + 6000 字上限，从根上避开键盘扩展内存/看门狗被杀。
2. **Skill 没真正进请求**：v2.0 的键盘包里曾缺失 GoutouSkill.md；本版把技能文件打进键盘扩展，
   同时编译期内嵌一份同文技能，资源丢了也有兜底，**构建流程会逐项验证**后再出 IPA。
3. **上下文没实际上传**：原版 JevContext 只在 App 测试页使用；本版把上下文真正接到键盘的 AI 请求里。

## 构建（GitHub Actions 云编译）

推到 GitHub 后在 Actions 页手动运行 **build-unsigned-ipa**，或推送 `v*` 标签自动构建。
下载产物 `JevJarvis-Ultimate-unsigned-ipa`（未签名 IPA）。

## 安装（全能签）

1. 下载 IPA → 全能签导入 → 用你自己的证书签名安装。
2. 系统设置 → 通用 → 键盘 → 添加「Jev Jarvis」，并打开「允许完全访问」。
3. 打开 App →「模型」页填 DeepSeek API Key（Base URL：`https://api.deepseek.com`，模型：`deepseek-chat`），
   或点「复制配置到剪贴板」后在键盘上「一键从剪贴板导入」。
4. 回到聊天：长按对方消息 → 复制 → 键盘点「分析剪贴板」。

## 上下文怎么用

- 自动：每次「分析剪贴板」记下对方消息；点一条候选记下你的回复（各限 12 条 / 1800 字，去重）。
- 待机页显示「上下文 N 条 · 分析自动携带」，可一键清空。
- 分析时历史以「【历史对话】对方：… / 我：…」格式上传，与当前消息区分。

---
# jev-chat-jarvis（iOS · 键盘版）

![Swift](https://img.shields.io/badge/Swift-5+-F05138.svg)
![Platform](https://img.shields.io/badge/platform-iOS%2016+-lightgrey.svg)
![Version](https://img.shields.io/badge/version-0.1.0-orange.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

中文 | [English](README.en.md)

聊天 App 收到一条消息 → 在**当前聊天 App 的键盘上**直接看到这句话的**意图、风险**和**候选回复**，点一下就进输入框。

不跳 App、不切后台、不申请录屏权限——**一个自定义键盘打通所有聊天软件**，任何输入框都能用。

<p align="center">
  <img src="docs/demo.gif" alt="键盘实际演示：长按复制对方消息 → 键盘上出意图/风险/候选 → 点按插入输入框" width="320">&nbsp;&nbsp;
  <img src="docs/setup.gif" alt="App 设置演示：键盘状态自检、三步启用、内置话术库" width="320">
</p>

## 反馈与帮助

**合作与反馈，请公众号私信**：

<table>
  <tr>
    <td align="center"><img src="docs/wechat-mp-qr.png" width="200" alt="扫码关注公众号"><br><sub>公众号</sub></td>
  </tr>
</table>

## 用法

### 1. 装到 iPhone

1. Mac 上双击打开 `JevJarvis.xcodeproj`（需 Xcode 15+，本工程用 Xcode 27 验证编译）
2. Xcode 左上角选 target **JevJarvis** → Signing & Capabilities → Team 选你的 Apple ID（免费个人账号即可；Xcode → Settings → Accounts 可添加）
3. 插上 iPhone，选它作为运行目标，`Cmd+R`。首次运行在手机上：设置 → 通用 → VPN与设备管理 → 信任你的开发者证书
4. 两个 target（App 和 JevKeyboard）都要选**同一个 Team**，否则 App Group 共享不通

> 免费个人账号签名 7 天过期，到期重新 `Cmd+R` 一次即可。

### 2. 启用键盘（手机上操作）

1. 设置 → 通用 → 键盘 → 键盘 → **添加新键盘** → 选「Jev 键盘」
2. 回到键盘列表，点「Jev 键盘」→ 打开 **允许完全访问**（联网 + 读剪贴板必须）
3. 打开 Jev Jarvis App →「模型」页：选个预设（智谱 `glm-4-flash` / DeepSeek 最快 / OpenRouter 一个 key 全模型），填 Key，点「测试连接」
4. 到「试一试」页跑一条消息，通了就是全通了

### 3. 在聊天 App 中使用

1. 长按对方那条消息 → **复制**
2. 输入框获得焦点，键盘切到 Jev（地球键切换）→ 点 **「分析剪贴板」**
3. 键盘上显示：意图 + 风险 0-9 + 行动建议 + 每话术 2 条候选（前稳后放）
4. 点中意的候选 → 文字直接进入当前输入框 → **发送由你手动完成**（本项目永不自动发送）

另有「分析输入框文字」按钮：分析你打到一半拿不准的话（读 `documentContextBeforeInput`）。

## 配置

全部在 App 内完成，改完即存、键盘即时生效（无需重启）：

- **生成层（必配）**：选择 OpenAI 兼容（`/chat/completions`）或 Anthropic 兼容（`/v1/messages`）服务，填写你自己的 API Key 和模型。本项目不提供生成服务或中转。地址带不带 `/v1`、填到动作段都能拼对；端点需要额外字段时可填写 JSON。**别用思考型模型**，思考占满额度会 0 条候选（错误信息里会直接点名）。
- **判断层（核心）**：TypeSafe Jev（systemone 接口），一次调用同时出 8 类意图概率分布 + 0-9 风险分布，并给候选排序；界面内置 TypeSafe 直连 / OpenRouter / Vercel AI Gateway 三个预设，网关地址、模型、key 全部可自定义。没配 key 时运行时自动退化为「盲起草」（只出候选），这不是配置开关而是兜底。地址带不带 `/v1`、填到动作段都能拼对。
- **判断层兜底（融合版新增）**：判断层未配置时不再是光秃秃的「未配置」——用**生成层模型**推测一版意图 + 风险 + 建议动作（标注「军师判断参考（模型推测）」），照常参与高风险重写，只作参考不影响出候选。
- **话术**：3 个生效槽位 × 每话术 2 条 = 最多 6 条候选（面板可滚动），内置 12 种话术（高情商 / 贴吧老哥 / 拒绝加班 / 卑微乙方 / 稳如老狗 / 已读乱回 / 鱼塘主 / 职场黑话 / 阴阳怪气 / 情绪价值 / 夸夸 / 讨好型人格），支持自定义（说明写「什么语气 + 别变成什么」最管用）。每话术一次请求、出 2 条（前稳后放），多话术并发。候选上限 40 字，要求像真人打字、不编造、每轮只做一个主动作。
- **键盘本地兜底配置**：全能签等自签重签后，App Group 可能不共享（症状：App 里配好、测试连接都成功，但键盘仍提示「还没配置生成层」）。两条路：① 在 App「模型」页点「复制配置到剪贴板」，再到键盘点「从剪贴板导入配置」（剪贴板是系统级共享，与 App Group 无关）；② 直接在键盘上点「键盘上直接配置」手填。配置存在键盘自己的容器里，永远可用。App 侧配置保留，互不覆盖。

### 内置技能（狗头军师 · 恋爱大师）

App 出厂即内置两套开源恋爱 skill，**默认开启**，每次分析自动携带到判断层与生成层（模型页可关）：

- **狗头军师**（分析心理）——蒸馏自 [shengjidaguai-china/goutoujunshi](https://github.com/shengjidaguai-china/goutoujunshi)（MIT）
- **恋爱大师**（给出回复）——蒸馏自 [tomwong001/qingsheng-skill](https://github.com/tomwong001/qingsheng-skill)（MIT）

携带的核心判断逻辑（与安卓「知识库启用版」同机制）：

> **先接住情绪 → 分清事实 → 给下一步 → 停止条件**

具体为：判断时先处理感受、再只把可见原文当事实、给一句首选建议与理由、最后给可执行的小动作/观察窗口/停止条件；生成回复时要求话术真实（不编经历）、每条只承载一个主动作、口语自然不 AI 味、明确拒绝即停、危险情境先保安全。知识库全文在模型页「查看内置知识库内容」可展开阅读。

**狗头军师方法库（融合版新增）**：内置狗头军师完整文献库——知识 20 篇 + 精选实战 10 篇（`Shared/JevKnowledge.swift`，由 `tools/gen_knowledge.py` 从上游仓库生成）。每次分析时，常驻四步口径 + 恋爱大师始终携带；消息文本命中文献标签（分手/冷战/前任/复合/吵架/邀约/拒绝/暧昧/操控/家暴等 60+ 标签）时，再按需把 1-2 篇相关文献带进生成层 prompt，把方法化进回复（不照抄、不提及资料本身）。完整目录可在模型页知识库预览里展开。

### 隐私边界

- 聊天内容只在点「分析」那一刻发往**你自己配置**的模型接口；无自建服务器、不落盘、不进日志
- API Key 存本机 App Group 私有容器，仅 App 与键盘可读
- 键盘不监听、不上传按键；「允许完全访问」随时可在系统设置里关闭或移除键盘

## 口径回归

`Shared/` 目录是 App 与键盘共用的单一口径层：意图集、风险量表、行动建议、话术库、起草 prompt、候选清洗和 URL 拼接规则都只在这一份实现里，两端行为一致。起草 prompt 面向通用聊天场景。

口径回归（Mac 上直接跑，不需要 iPhone）：

```bash
swiftc -o /tmp/jevcheck tools/PromptCheck/main.swift Shared/*.swift && /tmp/jevcheck
```

## 工程结构

```
├── project.yml            # xcodegen 工程定义（改完跑 `xcodegen generate`）
├── AGENTS.md              # 仓库协作指南（代码风格 / 提交规范 / 安全红线）
├── Shared/                # App 与键盘共用的单一口径层（仅 Foundation，无 UI）
│   ├── JevModel.swift     # 配置模型 + App Group 存储
│   ├── JevLocalization.swift # 中英文案与意图/风险/行动的本地化映射
│   ├── JevPrompts.swift   # 意图/风险/话术/内置知识库/prompt/清洗
│   ├── JevHTTP.swift      # 带总预算的 POST（429/5xx 退避重试）
│   ├── JevJudge.swift     # TypeSafe systemone：判断 + 排序
│   ├── JevDraft.swift     # OpenAI/Anthropic 起草
│   └── JevPipeline.swift  # 判断 → 每话术并发起草 → 排序
├── App/Sources/           # SwiftUI：开始（键盘状态）/ 模型 / 话术 / 试一试
├── App/Assets.xcassets/   # AppIcon（改设计见 tools/MakeAppIcon，别手改 PNG）
├── Keyboard/Sources/      # UIKit 键盘扩展（内存 <60MB 约束下的纯系统控件）
├── UITests/               # XCUITest：冷启动/Tab 遍历/键盘启用回归 + 上架截图采集
├── marketing/app-store-upload/  # App Store 上架截图（source 原图 + npm 生成脚本）
└── tools/
    ├── PromptCheck/       # 口径回归
    └── MakeAppIcon/       # 画 AppIcon：swiftc -O -o /tmp/makeappicon tools/MakeAppIcon/main.swift && /tmp/makeappicon App/Assets.xcassets/AppIcon.appiconset
```

编译自检（不需要证书）：

```bash
xcodegen generate
xcodebuild -project JevJarvis.xcodeproj -target JevJarvis -sdk iphoneos \
  -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```

没有 Mac 也能出包：仓库自带 [`.github/workflows/build-unsigned-ipa.yml`](.github/workflows/build-unsigned-ipa.yml)，推到 GitHub 后在 Actions 页手动点「Run workflow」，产物是**未签名 IPA**（含键盘扩展），下载后用全能签/爱思等工具自签安装即可。官方流程另见 [docs/TESTFLIGHT.md](docs/TESTFLIGHT.md)。

## 已知限制

- **复制的消息不含上下文**：剪贴板里通常只有那一条。如果聊天 App 支持复制引用内容，可借此带上被引文字；多轮上下文见路线图
- 键盘高度固定 320pt，候选多时可滚动；横屏未适配
- App Group 需两个 target 同一 Team 签名；免费个人账号一般可用，个别情况下需付费账号
- 密码框等安全输入会强制系统键盘（系统行为，不是 bug）
- 免费账号签的键盘 7 天过期需重装

## 路线图

1. **感知自动化**：主 App 走 ScreenCaptureKit（iOS 26+ 的 `UIBackgroundModes: screen-capture`）自动读屏分析，把候选写进 App Group，键盘面板**主动展示**已就绪的候选——键盘继续当展示+填入端，感知与填入解耦
2. 键盘内完整 QWERTY（免切换打字）
3. 群聊适配（`@` 前缀）、知识库（联系人档案/常驻笔记）
4. 定时换签名 / TestFlight 分发 —— 借他人开发者账号的完整流程见 [`docs/TESTFLIGHT.md`](docs/TESTFLIGHT.md)

## 许可

Copyright © 2026 eatmoreduck、Xlff 与 jev-chat 贡献者。代码以 [MIT](LICENSE) 协议开源，另见 [NOTICE](NOTICE)。

- **可以商用**：个人和公司都可以使用、修改、再分发，不需要付费或事先授权。
- **必须注明出处**：分发或商用时保留 `LICENSE` 与 `NOTICE`，并写明来源。
- **不要用**「秒回」「Jev 聊天助手」「jev-chat」「jev-jarvis-ios」名称暗示由原作者出品或背书。
- **仅供正当用途**：本项目只辅助你自己真诚的日常沟通。严禁用于任何违法违规行为，**包括但不限于任何形式的诈骗（杀猪盘、养老诈骗、婚恋诈骗）、冒充他人、骚扰、垃圾营销**。
- **免责声明**：本项目按「现状」提供，作者不参与、不知情、也不为任何使用者的具体使用行为负责，由此产生的一切后果与法律责任由使用者自行承担。本项目只处理你自己设备上、你自己有权查看的聊天，候选只插入输入框，**永不自动发送**。
- 完整风险告知见置顶 issue：[使用声明与风险告知](https://github.com/jev-chat/jev-chat-jarvis-ios/issues/2)。
