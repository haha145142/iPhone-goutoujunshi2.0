import Foundation
#if canImport(UIKit)
import UIKit
#endif

// MARK: - 配置模型

/// 生成层 API 形状。key 所在的组决定请求形状（与 macOS 版同一规则）。
enum APIKind: String, Codable, CaseIterable, Identifiable {
    case openai
    case anthropic

    var id: String { rawValue }
    var label: String {
        switch self {
        case .openai: return "OpenAI 兼容（/chat/completions）"
        case .anthropic: return "Anthropic 兼容（/v1/messages）"
        }
    }
}

struct ProviderPreset: Identifiable, Hashable {
    let id: String
    let name: String
    let kind: APIKind
    let base: String
    let model: String
    let keyHint: String

    /// DeepSeek 国内直连、智谱 glm-4-flash、OpenRouter、通义与本地 Ollama。
    static let all: [ProviderPreset] = [
        .init(id: "zhipu", name: "智谱（glm-4-flash 免费）", kind: .openai,
              base: "https://open.bigmodel.cn/api/paas/v4", model: "glm-4-flash", keyHint: "open.bigmodel.cn 的 API Key"),
        .init(id: "deepseek", name: "DeepSeek 官方", kind: .openai,
              base: "https://api.deepseek.com", model: "deepseek-chat", keyHint: "platform.deepseek.com 的 sk-…"),
        .init(id: "openrouter", name: "OpenRouter", kind: .openai,
              base: "https://openrouter.ai/api/v1", model: "deepseek/deepseek-chat-v3.1", keyHint: "sk-or-…"),
        .init(id: "dashscope", name: "阿里通义（兼容模式）", kind: .openai,
              base: "https://dashscope.aliyuncs.com/compatible-mode/v1", model: "qwen-flash", keyHint: "sk-…"),
        .init(id: "moonshot", name: "月之暗面 Kimi", kind: .openai,
              base: "https://api.moonshot.cn/v1", model: "moonshot-v1-8k", keyHint: "sk-…"),
        .init(id: "siliconflow", name: "硅基流动", kind: .openai,
              base: "https://api.siliconflow.cn/v1", model: "Qwen/Qwen2.5-7B-Instruct", keyHint: "sk-…"),
        .init(id: "ollama", name: "Ollama（Mac 局域网）", kind: .openai,
              base: "http://127.0.0.1:11434/v1", model: "qwen2.5:7b", keyHint: "随便填，如 ollama"),
        .init(id: "custom", name: "自定义…", kind: .openai, base: "", model: "", keyHint: ""),
    ]
}

/// 判断层预设。Jev native 在 waitlist，网关同形状只换地址+模型+key。
struct JudgePreset: Identifiable, Hashable {
    let id: String
    let name: String
    let base: String
    let model: String
    let keyHint: String

    static let all: [JudgePreset] = [
        .init(id: "typesafe", name: "TypeSafe 直连",
              base: "https://api.typesafe.ai", model: "jev-latest",
              keyHint: "api.typesafe.ai 的 key"),
        .init(id: "openrouter", name: "OpenRouter 网关",
              base: "https://openrouter.ai/api/alpha/decisions", model: "typesafe/jev-1.13",
              keyHint: "OpenRouter 的 sk-or-…"),
        .init(id: "vercel", name: "Vercel AI Gateway",
              base: "https://ai-gateway.vercel.sh/v1/evaluate", model: "typesafe-ai/jev",
              keyHint: "Vercel AI Gateway 的 key"),
        .init(id: "custom", name: "自定义…", base: "", model: "", keyHint: ""),
    ]
}

/// 生成层实际生效的那一组。URL / key / 模型同源，不跨来源混搭——
/// 混搭就是拿 A 家的 key 调 B 家的端点，换来一个看不懂的 401。
struct GenCredentials {
    var kind: APIKind
    var base: String
    var key: String
    var model: String
    var extraJSON: String
}

/// 话术槽上限。iOS 比 macOS 少一个：手机屏幕高度有限，3 槽 × 2 条 = 最多 6 条候选
/// 会把键盘顶到半个屏幕以上，2 槽 4 条是屏幕占用与可选性的平衡点。
/// 存在的槽位依然保留在配置里（只是不参与），日后想放开只改这一个数。
let MAX_SLOTS = 5

/// 全部配置。存 App Group，键盘扩展与主 App 共享同一份。
struct JevConfig: Codable, Equatable {
    // 生成层（必须配置自己的服务地址、API Key 和模型）
    var genKind: APIKind = .openai
    var genBase: String = "https://open.bigmodel.cn/api/paas/v4"
    var genKey: String = ""
    var genModel: String = "glm-4-flash"
    /// 额外请求体字段（JSON），端点要靠额外字段关思考模式时填，如 {"enable_thinking":false}
    var genExtraJSON: String = ""

    // 判断层（Jev：意图 + 风险 + 排序，核心判断引擎）。
    // 没配 key 时管线自动退化为「盲起草」——只出候选、无意图/风险，运行时兜底而非配置开关。
    var judgeBase: String = "https://api.typesafe.ai"
    var judgeKey: String = ""
    var judgeModel: String = "jev-latest"

    /// 话术槽位。空串 = 不用（与 macOS 版 NONE_LABEL 同语义）。最多 3 槽。
    var slots: [String] = ["狗头军师", "高情商话术"]

    /// 用户自定义话术（名字 = 说明），同名覆盖内置。
    var customTones: [String: String] = [:]

    var activeSlots: [String] { Array(slots.filter { !$0.isEmpty }.prefix(MAX_SLOTS)) }

    /// 生成层凭据完全来自用户配置，不会回退到项目提供的服务。
    var generation: GenCredentials {
        GenCredentials(kind: genKind, base: genBase, key: genKey,
                       model: genModel, extraJSON: genExtraJSON)
    }
}

/// 键盘侧回写的运行状态，主 App 的引导页用它判断「键盘装没装、全访问给没给」。
struct KeyboardStatus: Codable, Equatable {
    var lastSeen: Date
    var hasFullAccess: Bool
}

// MARK: - App Group 存储

/// 配置与状态的唯一存放点。键值放 App Group UserDefaults：
/// 键盘扩展只有拿到「允许完全访问」后才能读共享容器，正好与联网条件一致。
enum JevStore {
    static let appGroupID = "group.com.jevchat.jarvis"
    private static let configKey = "jev.config.v1"
    /// 自定义话术独立副本：配置块同步出问题时，话术仍能单独到达键盘
    private static let customTonesKey = "jev.customTones.v1"
    private static let removedGenerationBase = "http://101.132.131.220:11111/v1"
    private static let statusKey = "jev.kbstatus.v1"
    private static let canaryKey = "jev.canary.v1"

    /// App Group 共享库。签名没带 app-group entitlement 时，suite 会静默退化成
    /// 「当前进程私有」的容器（App 与键盘互不可见）——所以不能只靠它。
    static var groupDefaults: UserDefaults {
        UserDefaults(suiteName: appGroupID) ?? .standard
    }

    /// 本进程真正的私有库（无需任何 entitlement）。键盘通过剪贴板导入的配置存这里。
    static var privateDefaults: UserDefaults { .standard }

    /// App Group 容器是否真的可写可读（签名没带上 entitlement 时 suite 会静默退化为私有容器）。
    static var groupWritable: Bool {
        let stamp = "t\(Date().timeIntervalSince1970)"
        groupDefaults.set(stamp, forKey: canaryKey)
        return groupDefaults.string(forKey: canaryKey) == stamp
    }

    private static func decodeConfig(_ store: UserDefaults) -> JevConfig? {
        guard let data = store.data(forKey: configKey),
              let cfg = try? JSONDecoder().decode(JevConfig.self, from: data) else { return nil }
        return cfg
    }

    static func loadConfig() -> JevConfig {
        let groupCfg = decodeConfig(groupDefaults)
        let privateCfg = decodeConfig(privateDefaults)
        if var cfg = groupCfg ?? privateCfg {
            // 独立副本里的话术也合并进来（配置块没带到时的兜底）
            for (k, v) in loadCustomTonesStandalone() where cfg.customTones[k] == nil {
                cfg.customTones[k] = v
            }
            // 双保险：另一个容器里若有这边没有的自定义话术，合并进来
            let other = groupCfg == nil ? nil : privateCfg
            if let other, other.customTones != cfg.customTones {
                var changed = false
                for (k, v) in other.customTones where cfg.customTones[k] == nil {
                    cfg.customTones[k] = v; changed = true
                }
                if changed { saveConfig(cfg) }
            }
            if cfg.genBase == removedGenerationBase {
                let preset = ProviderPreset.all.first { $0.id == "zhipu" }
                cfg.genKind = preset?.kind ?? .openai
                cfg.genBase = preset?.base ?? ""
                cfg.genKey = ""
                cfg.genModel = preset?.model ?? ""
                cfg.genExtraJSON = ""
                saveConfig(cfg)
            }
            return cfg
        }
        return JevConfig()
    }

    static func saveConfig(_ cfg: JevConfig) {
        if let data = try? JSONEncoder().encode(cfg) {
            groupDefaults.set(data, forKey: configKey)
            privateDefaults.set(data, forKey: configKey)
        }
    }

    // MARK: 自定义话术独立存储（不依赖配置块，多通道保证到达键盘）

    static func saveCustomTonesStandalone(_ tones: [String: String]) {
        let clean = tones.filter { $0 != NONE_LABEL && !$1.isEmpty }
        if let data = try? JSONEncoder().encode(clean) {
            groupDefaults.set(data, forKey: customTonesKey)
            privateDefaults.set(data, forKey: customTonesKey)
        }
    }

    /// 合并 group + private 两个独立副本
    static func loadCustomTonesStandalone() -> [String: String] {
        var out: [String: String] = [:]
        for store in [groupDefaults, privateDefaults] {
            if let data = store.data(forKey: customTonesKey),
              let t = try? JSONDecoder().decode([String: String].self, from: data) {
                for (k, v) in t where out[k] == nil { out[k] = v }
            }
        }
        return out
    }

    // MARK: 无 App Group 时的配置搬运（全能签等第三方证书）

    /// 主 App：把当前配置编码成 JSON 放到系统剪贴板，键盘端「导入配置」读取。
    @discardableResult
    static func exportConfigToPasteboard() -> Bool {
        guard let data = try? JSONEncoder().encode(loadConfig()),
              let s = String(data: data, encoding: .utf8) else { return false }
        UIPasteboard.general.string = s
        return true
    }

    /// 键盘端：从剪贴板读取配置 JSON，存入本进程私有库。
    @discardableResult
    static func importConfigFromPasteboard() -> Bool {
        guard let s = UIPasteboard.general.string?
            .trimmingCharacters(in: .whitespacesAndNewlines),
              let data = s.data(using: .utf8),
              let cfg = try? JSONDecoder().decode(JevConfig.self, from: data) else { return false }
        saveConfig(cfg)
        return true
    }

    /// 静默自动导入：剪贴板是配置 JSON 且与当前存的不同才保存。
    /// 复制的聊天消息解码不成 JevConfig，会被自然忽略，不影响分析。
    /// 解决「全能签多开改了键盘 bundle ID、App Group 实际读不到」时自定义话术不同步的问题。
    @discardableResult
    static func autoImportConfigFromPasteboard() -> Bool {
        guard let s = UIPasteboard.general.string?
            .trimmingCharacters(in: .whitespacesAndNewlines),
              let data = s.data(using: .utf8),
              let cfg = try? JSONDecoder().decode(JevConfig.self, from: data) else { return false }
        let current = loadConfig()
        // 只有真有差异（多了话术、改了槽位或 Key）才落盘，避免重复写。
        guard cfg != current else { return false }
        saveConfig(cfg)
        saveCustomTonesStandalone(cfg.customTones)
        return true
    }

    // MARK: 内置知识库开关

    private static let knowledgeEnabledKey = "jev.knowledgeEnabled.v1"

    /// 「自动携带恋爱知识库（狗头军师·恋爱大师）」开关，默认开。
    /// 双写 group/private：第三方签名 group 不通时，键盘读不到 App 的设置，会落到默认值 true，
    /// 与默认行为一致，不影响使用。
    static var knowledgeEnabled: Bool {
        get {
            if let v = groupDefaults.object(forKey: knowledgeEnabledKey) as? Bool { return v }
            if let v = privateDefaults.object(forKey: knowledgeEnabledKey) as? Bool { return v }
            return true
        }
        set {
            groupDefaults.set(newValue, forKey: knowledgeEnabledKey)
            privateDefaults.set(newValue, forKey: knowledgeEnabledKey)
        }
    }

    static func loadKeyboardStatus() -> KeyboardStatus? {
        guard let data = groupDefaults.data(forKey: statusKey),
              let s = try? JSONDecoder().decode(KeyboardStatus.self, from: data) else { return nil }
        return s
    }

    static func saveKeyboardStatus(_ s: KeyboardStatus) {
        if let data = try? JSONEncoder().encode(s) {
            groupDefaults.set(data, forKey: statusKey)
        }
    }

    /// 密钥展示用掩码
    static func masked(_ key: String) -> String {
        guard !key.isEmpty else { return "（未配置）" }
        if key.count <= 8 { return String(repeating: "•", count: max(key.count - 2, 2)) + String(key.suffix(2)) }
        return String(key.prefix(4)) + "…" + String(key.suffix(4))
    }

#if DEBUG
    private static let diagKey = "jev.diag.v1"

    /// 键盘侧自检日志。键盘扩展连不上 Xcode 看控制台，所以写进 App Group，
    /// 再用 `xcrun devicectl device copy from --domain-type appGroupDataContainer` 拉出来看。
    static func diag(_ line: String) {
        let stamp = String(format: "%.3f", Date().timeIntervalSince1970)
        let prev = groupDefaults.string(forKey: diagKey) ?? ""
        groupDefaults.set(String((prev + "[\(stamp)] \(line)\n").suffix(6000)), forKey: diagKey)
    }
#endif
}
