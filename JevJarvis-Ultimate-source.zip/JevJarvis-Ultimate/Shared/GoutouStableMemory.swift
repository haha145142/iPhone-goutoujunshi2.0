import Foundation

// MARK: - 键盘扩展被系统强杀时的断点记录（诊断用）
//
// iOS 自定义键盘扩展一旦被系统强制退出（内存压力/看门狗超时），
// 用户看到的只是「键盘跳回系统键盘」，没有任何崩溃日志可查。
// 这里把分析流程的每个关键节点写进 UserDefaults.standard：
// 如果扩展在分析中途被杀，下次唤起键盘时，待机页会提示
// 「上次被系统中断于：N」，一眼看出卡在哪个环节，方便定位。
// 同时它自带一次「中断记忆」：中断后重新点分析会照常重新开始。

enum GoutouStableMemory {

    private static let key = "goutou.v2.crash.stage"

    /// 标记当前流程进行到哪一步（覆盖写）。
    static func stage(_ s: String) {
        UserDefaults.standard.set(s, forKey: key)
    }

    /// 流程正常走完，清掉断点。
    static func finished() {
        UserDefaults.standard.removeObject(forKey: key)
    }

    /// 上一次流程中断在哪个环节；没有中断记录返回 nil。
    static func previousStage() -> String? {
        let s = UserDefaults.standard.string(forKey: key) ?? ""
        return s.isEmpty ? nil : s
    }
}
