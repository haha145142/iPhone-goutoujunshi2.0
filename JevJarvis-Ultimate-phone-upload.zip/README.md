# JevJarvis 终极融合版（狗头军师终极融合版）

以 Jev Jarvis v2.0 原版完整界面/键盘/API 设置/知识库为基础，融合 666 版狗头军师 Skill 与自动上下文，专为 iPhone + 全能签自签 + DeepSeek API 打造。

## 功能对照

| 能力 | 原版 v2.0 | 666 | 本融合版 |
|---|---|---|---|
| 完整面板（意图/风险/建议/话术分类/百分比/换一批/发送） | ✅ | ❌ | ✅ |
| 狗头军师 666 Skill 真正进入 AI 请求 | ❌（没带技能，回复平淡） | ✅ | ✅（技能置顶 + 内嵌常量兜底） |
| 自动上下文（对方/我 各自动记录，下次分析携带） | ❌ | ✅ | ✅（12 条 / 1800 字，去重） |
| 真人化回复（自然/幽默/有分寸，拒绝客服腔） | ❌ | ✅ | ✅ |
| 防闪退加固（剪贴板限长 + 自动释放池 + 断点记忆） | 部分 | ❌ | ✅ |

## 关键修复（相对 Real666 崩溃版）

- 剪贴板读取：autoreleasepool + 1200 字上限（Real666 因大段复制内存峰值被杀）。
- 上下文/知识库：只进主 App，不塞进键盘扩展（键盘 50MB 内存上限；Real666 把知识库塞进键盘是崩溃主因之一）。
- PrimaryLanguage=en-US（键盘弹起宿主崩溃的系统 bug 规避）。
- 断点记忆：被系统中断后待机页提示「上次中断于：N」，不再无声跳回系统键盘。

## 构建 / 安装

1. 推送到 GitHub Actions（工作流 build-unsigned-ipa.yml），下载 JevJarvis-Ultimate-unsigned-ipa。
2. 全能签自签 → 安装 → 系统设置添加键盘并开「允许完全访问」。
3. App「模型」页填 DeepSeek API Key（Base https://api.deepseek.com，模型 deepseek-chat）。
4. 长按聊天消息复制 → 键盘「分析剪贴板」→ 出意图/风险/建议 + 各话术候选；点候选插入自动记「我」，待机页可清空上下文。

## 上下文用法

- 对方消息：点「分析剪贴板」自动记录（去重：30 分钟内同文本不重复记）。
- 我的回复：点候选插入自动记录（标「[草稿·未发送]」）。
- 最多 12 条 / 1800 字，待机页显示条数，可一键清空。

---
# jev-chat-jarvis（iOS · 键盘版）

![Swift](https://img.shields.io/badge/Swift-5+-F05138.svg)
![Platform](https://img.shields.io/badge/platform-iOS%2016+-lightgrey.svg)
![Version](https://img.shields.io/badge/version-0.2.0-orange.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

中文 | [English](README.en.md)

聊天 App 收到一条消息 → 在**当前聊天 App 的键盘上**直接看到这句话的**意图、风险**和**候选回复**，点一下就进输入框。

不跳 App、不切后台、不申请录屏权限——**一个自定义键盘打通所有聊天软件**，任何输入框都能用。懒得复制就开**直播模式**（可选）：广播扩展在本地 OCR 读屏，键盘上直接出「读屏幕分析」，连长按复制都省了。

<p align="center">
  <img src="docs/demo.gif" alt="键盘实际演示：长按复制对方消息 → 键盘上出意图/风险/候选 → 点按插入输入框" width="320">&nbsp;&nbsp;
  <img src="docs/setup.gif" alt="App 设置演示：键盘状态自检、三步启用、内置话术库" width="320">
</p>

## 反馈与帮助

**合作与反馈，请公众号私信**：

<table>
  <tr>
    <td align="center"><img src="docs/wechat-mp-qr.png" width="200" alt="扫码关注公众号"><br><sub>公众号</sub></td>
  </tr>
</table>

## 用法

### 1. 装到 iPhone

1. Mac 上双击打开 `JevJarvis.xcodeproj`（需 Xcode 15+，本工程用 Xcode 27 验证编译）
2. Xcode 左上角选 target **JevJarvis** → Signing & Capabilities → Team 选你的 Apple ID（免费个人账号即可；Xcode → Settings → Accounts 可添加）
3. 插上 iPhone，选它作为运行目标，`Cmd+R`。首次运行在手机上：设置 → 通用 → VPN与设备管理 → 信任你的开发者证书
4. 两个 target（App 和 JevKeyboard）都要选**同一个 Team**，否则 App Group 共享不通

> 免费个人账号签名 7 天过期，到期重新 `Cmd+R` 一次即可。

### 2. 启用键盘（手机上操作）

1. 设置 → 通用 → 键盘 → 键盘 → **添加新键盘** → 选「Jev 键盘」
2. 回到键盘列表，点「Jev 键盘」→ 打开 **允许完全访问**（联网 + 读剪贴板必须）
3. 打开 Jev Jarvis App →「模型」页：选个预设（智谱 `glm-4-flash` / DeepSeek 最快 / OpenRouter 一个 key 全模型），填 Key，点「测试连接」
4. 到「试一试」页跑一条消息，通了就是全通了

### 3. 在聊天 App 中使用

1. 长按对方那条消息 → **复制**
2. 输入框获得焦点，键盘切到 Jev（地球键切换）→ 点 **「分析剪贴板」**
3. 键盘上显示：意图 + 风险 0-9 + 行动建议 + 每话术 2 条候选（前稳后放）
4. 点中意的候选 → 文字直接进入当前输入框 → **发送由你手动完成**（本项目永不自动发送）

另有「分析输入框文字」按钮：分析你打到一半拿不准的话（读 `documentContextBeforeInput`）。

### 4. 直播模式（免复制，可选）

不想每条消息都长按复制？在 App 的「直播」页点系统广播按钮 → 选「Jev 直播」→ 开始广播：

1. 广播扩展（`JevLive`）每 2 秒取一帧，**本机 Vision OCR**（accurate 档，中文）识别聊天画面，按气泡横向位置分「我方 / 对方」，洗掉时间戳和底部 UI。**带会话门控**：只有画面同时出现左右两侧气泡（真聊天）才产生识别内容，切去设置/相册等其他 App 时不留任何识别结果（iOS 不提供「当前前台 App」API，按 App 白名单过滤做不到，这是能做到的最强近似）
2. 快照写 App Group：App「直播」页实时还原对话；键盘待机页亮出「读屏幕分析：『对方最新一条』」，还有「回复更早」列表——你滚动浏览聊天历史时它也在看，更早的消息一样能挑着回。点一下直接出候选，全程不用碰剪贴板
3. 只有当你触发分析时，识别出的对话文本才会发往你自己配置的模型；OCR 全程在本机完成，状态栏紫色录屏指示全程可见，停止就在控制中心

细节与真机测试步骤见 [`docs/LIVE_MODE.md`](docs/LIVE_MODE.md)。注意：广播面板是系统 UI，**只在真机上响应真人点按**（模拟器不弹）。

## 配置

全部在 App 内完成，改完即存、键盘即时生效（无需重启）：

- **生成层（必配）**：选择 OpenAI 兼容（`/chat/completions`）或 Anthropic 兼容（`/v1/messages`）服务，填写你自己的 API Key 和模型。本项目不提供生成服务或中转。地址带不带 `/v1`、填到动作段都能拼对；端点需要额外字段时可填写 JSON。**别用思考型模型**，思考占满额度会 0 条候选（错误信息里会直接点名）。
- **判断层（核心）**：TypeSafe Jev（systemone 接口），一次调用同时出 8 类意图概率分布 + 0-9 风险分布，并给候选排序；界面内置 TypeSafe 直连 / OpenRouter / Vercel AI Gateway 三个预设，网关地址、模型、key 全部可自定义。没配 key 时运行时自动退化为「盲起草」（只出候选），这不是配置开关而是兜底。地址带不带 `/v1`、填到动作段都能拼对。
- **话术**：2 个生效槽位（iOS 屏幕所限，配置里保留 3 槽，日后放开只改一个数），内置 12 种话术（高情商 / 贴吧老哥 / 拒绝加班 / 卑微乙方 / 稳如老狗 / 已读乱回 / 鱼塘主 / 职场黑话 / 阴阳怪气 / 情绪价值 / 夸夸 / 讨好型人格），支持自定义（说明写「什么语气 + 别变成什么」最管用）。每话术一次请求、出 2 条（前稳后放），多话术并发。

### 隐私边界

- 聊天内容只在点「分析」那一刻发往**你自己配置**的模型接口；无自建服务器、不落盘、不进日志
- API Key 存本机 App Group 私有容器，仅 App 与键盘可读
- 键盘不监听、不上传按键；「允许完全访问」随时可在系统设置里关闭或移除键盘

## 口径回归

`Shared/` 目录是 App 与键盘共用的单一口径层：意图集、风险量表、行动建议、话术库、起草 prompt、候选清洗和 URL 拼接规则都只在这一份实现里，两端行为一致。起草 prompt 面向通用聊天场景。

口径回归（Mac 上直接跑，不需要 iPhone）：

```bash
# 管线口径：意图/风险/话术/prompt/清洗
swiftc -o /tmp/jevcheck tools/PromptCheck/main.swift Shared/*.swift && /tmp/jevcheck

# 直播 OCR 链路：识别/左右归属/清洗/会话门控/模糊去重/目标累积
tools/run_live_smoke.sh
```

## 工程结构

```
├── project.yml            # xcodegen 工程定义（改完跑 `xcodegen generate`）
├── AGENTS.md              # 仓库协作指南（代码风格 / 提交规范 / 安全红线）
├── Shared/                # App 与键盘共用的单一口径层（仅 Foundation，无 UI）
│   ├── JevModel.swift     # 配置模型 + App Group 存储
│   ├── JevLocalization.swift # 中英文案与意图/风险/行动的本地化映射
│   ├── JevPrompts.swift   # 意图/风险/话术/prompt/清洗
│   ├── JevHTTP.swift      # 带总预算的 POST（429/5xx 退避重试）
│   ├── JevJudge.swift     # TypeSafe systemone：判断 + 排序
│   ├── JevDraft.swift     # OpenAI/Anthropic 起草
│   └── JevPipeline.swift  # 判断 → 每话术并发起草 → 排序
├── App/Sources/           # SwiftUI：开始（键盘状态）/ 模型 / 话术 / 直播 / 试一试
├── App/Assets.xcassets/   # AppIcon（改设计见 tools/MakeAppIcon，别手改 PNG）
├── Keyboard/Sources/      # UIKit 键盘扩展（内存 <60MB 约束下的纯系统控件）
├── Broadcast/Sources/     # ReplayKit 广播上传扩展（录屏→本地 OCR，50MB 内存硬顶内只做识别与落盘）
├── Shared/JevLive.swift   # 直播模式共享层：快照模型 / App Group 存储 / OCR 引擎 / 对话解析
├── UITests/               # XCUITest：冷启动/Tab 遍历/键盘启用回归 + 上架截图采集 + 直播真机链路
├── marketing/app-store-upload/  # App Store 上架截图（source 原图 + npm 生成脚本）
└── tools/
    ├── PromptCheck/       # 口径回归
    ├── live_ocr_smoke.swift  # 直播 OCR 链路冒烟（Mac 上跑，不用 iPhone）
    └── MakeAppIcon/       # 画 AppIcon：swiftc -O -o /tmp/makeappicon tools/MakeAppIcon/main.swift && /tmp/makeappicon App/Assets.xcassets/AppIcon.appiconset
```

编译自检（不需要证书）：

```bash
xcodegen generate
xcodebuild -project JevJarvis.xcodeproj -target JevJarvis -sdk iphoneos \
  -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```

## 已知限制

- **复制的消息不含上下文**：剪贴板里通常只有那一条。如果聊天 App 支持复制引用内容，可借此带上被引文字；要自动带上下文用「直播模式」
- 键盘高度固定 320pt，候选多时可滚动；横屏未适配
- App Group 需两个 target 同一 Team 签名；免费个人账号一般可用，个别情况下需付费账号
- 密码框等安全输入会强制系统键盘（系统行为，不是 bug）
- 免费账号签的键盘 7 天过期需重装
- 直播模式：广播面板只在真机上响应真人点按（模拟器不弹）；左右归属是横向位置启发式，引用块/群聊可能判错边；识别每 2 秒一次，不是逐字逐句的实时字幕

## 路线图

1. **感知自动化**：直播模式（ReplayKit 广播 + 本地 OCR）已落地键盘出口；下一步做键盘打开期间新消息自动出候选（带开关，避免白烧 token）与群聊 sender 区分
2. 键盘内完整 QWERTY（免切换打字）
3. 群聊适配（`@` 前缀）、知识库（联系人档案/常驻笔记）
4. 定时换签名 / TestFlight 分发 —— 借他人开发者账号的完整流程见 [`docs/TESTFLIGHT.md`](docs/TESTFLIGHT.md)

## 许可

Copyright © 2026 eatmoreduck、Xlff 与 jev-chat 贡献者。代码以 [MIT](LICENSE) 协议开源，另见 [NOTICE](NOTICE)。

- **可以商用**：个人和公司都可以使用、修改、再分发，不需要付费或事先授权。
- **必须注明出处**：分发或商用时保留 `LICENSE` 与 `NOTICE`，并写明来源。
- **不要用**「秒回」「Jev 聊天助手」「jev-chat」「jev-jarvis-ios」名称暗示由原作者出品或背书。
- **仅供正当用途**：本项目只辅助你自己真诚的日常沟通。严禁用于任何违法违规行为，**包括但不限于任何形式的诈骗（杀猪盘、养老诈骗、婚恋诈骗）、冒充他人、骚扰、垃圾营销**。
- **免责声明**：本项目按「现状」提供，作者不参与、不知情、也不为任何使用者的具体使用行为负责，由此产生的一切后果与法律责任由使用者自行承担。本项目只处理你自己设备上、你自己有权查看的聊天，候选只插入输入框，**永不自动发送**。
- 完整风险告知见置顶 issue：[使用声明与风险告知](https://github.com/jev-chat/jev-chat-jarvis-ios/issues/2)。
