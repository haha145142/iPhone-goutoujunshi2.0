import Foundation

/// 终极融合版自动上下文：最近 8~16 条聊天记忆，下次分析自动携带。
///
/// 设计目标（对应需求「自动保存最近 8~16 条聊天上下文，下次分析自动携带，
/// 区分双方消息，避免重复记录」）：
///  - 对方消息：点「分析剪贴板」时自动写入（roleOther = "对方"）；
///  - 我的回复：点候选插入时自动写入（roleMe = "我"，带「已插入未发送」标记）；
///  - 去重：同一角色同一条文本 30 分钟内不重复记（避免「换一批」反复分析同一句话）；
///  - 限长：单条 ≤ 500 字、总量 ≤ 12 条 / 1800 字，防止把长文/大上下文塞爆请求；
///  - 渲染：`对方：…` / `我：…` 交替成块，标为「历史对话」，模型可区分双方消息。
///
/// 存储：UserDefaults（App Group 未启用时键盘本地），单线程访问、无强解包，
/// 纯 Foundation，不增加任何并发/内存压力（Real666 的崩溃点不在上下文，但这里
/// 仍然刻意写成最朴素的实现，杜绝潜在 trap）。
enum JevContext {
    struct Entry: Equatable {
        let role: String
        let text: String
        let date: Date
    }

    static let roleOther = "对方"
    static let roleMe = "我"

    static let maxTurns = 12
    static let maxChars = 1800
    static let lineCap = 500

    private static let storeKey = "goutou.v2.ultimate.context"
    private static let defaults = UserDefaults.standard

    /// 当前已存条数（待机页显示用）。
    static var count: Int { load().count }

    private struct Box: Codable {
        var role: String
        var text: String
        var date: Date
    }

    private static func persist(_ entries: [Entry]) {
        let boxes = entries.map { Box(role: $0.role, text: $0.text, date: $0.date) }
        if let data = try? JSONEncoder().encode(boxes) {
            defaults.set(data, forKey: storeKey)
        }
    }

    static func load() -> [Entry] {
        guard let data = defaults.data(forKey: storeKey),
              let boxes = try? JSONDecoder().decode([Box].self, from: data)
        else { return [] }
        return boxes.map { Entry(role: $0.role, text: $0.text, date: $0.date) }
    }

    /// 追加一条。去重 + 限长 + 总量裁剪都在这里，调用方不需要关心。
    static func append(role: String, text: String) {
        let clean = String(text.trimmingCharacters(in: .whitespacesAndNewlines).prefix(lineCap))
        guard !clean.isEmpty else { return }

        var entries = load()
        let now = Date()
        // 去重：同角色、同文本、30 分钟内已记过 → 跳过（"换一批"反复分析同一句不刷屏）。
        let duplicated = entries.suffix(8).contains { e in
            e.role == role && e.text == clean
                && now.timeIntervalSince(e.date) >= 0
                && now.timeIntervalSince(e.date) < 1800
        }
        guard !duplicated else { return }

        entries.append(Entry(role: role, text: clean, date: now))
        // 总量裁剪：先按条数，再按字符数从旧到新裁。
        if entries.count > maxTurns {
            entries = Array(entries.suffix(maxTurns))
        }
        var total = entries.reduce(0) { $0 + $1.text.count }
        while total > maxChars, entries.count > 1 {
            entries.removeFirst()
            total = entries.reduce(0) { $0 + $1.text.count }
        }
        persist(entries)
    }

    static func clear() {
        defaults.removeObject(forKey: storeKey)
    }

    /// 渲染成 `对方：…` / `我：…` 交替块，供请求注入。
    static func promptBlock(_ entries: [Entry], language: JevLanguage) -> String {
        guard !entries.isEmpty else { return "" }
        let lines = entries.map { "\($0.role)：\($0.text)" }
        let header = language == .english
            ? "Conversation history (already happened, oldest first):"
            : "历史对话（在此之前已发生，按时间顺序，最后一条是最近的）："
        return header + "\n" + lines.joined(separator: "\n")
    }
}
