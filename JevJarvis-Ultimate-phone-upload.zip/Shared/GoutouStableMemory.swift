import Foundation

/// 崩溃断点记忆：键盘扩展被系统强制退出（跳回系统键盘）时，把最后执行到的环节
/// 记进 UserDefaults，下次唤起在待机页提示「上次被中断于：N」，并自动清空。
/// 纯 Foundation，无强解包，单线程访问（键盘主线程），写入量极小，不会引起内存问题。
enum GoutouStableMemory {
    private static let stageKey = "goutou.v2.crash.stage"
    private static let defaults = UserDefaults.standard

    /// 记下当前执行环节（覆盖写，只保留最新一个）。
    static func stage(_ value: String) {
        defaults.set(value, forKey: stageKey)
    }

    /// 上次被系统中断在哪个环节；没有则为 nil。
    static func previousStage() -> String? {
        defaults.string(forKey: stageKey)
    }

    /// 正常走完（出候选/出错兜底）时清掉断点。
    static func finished() {
        defaults.removeObject(forKey: stageKey)
    }
}
